#include "ros/ros.h"

#include "std_msgs/Bool.h"
#include "std_msgs/Int8.h"
#include "std_msgs/Int16.h"
#include "std_msgs/String.h"
#include "std_msgs/Float32.h"
#include "geometry_msgs/Twist.h"
#include "geometry_msgs/PoseStamped.h"
#include "geometry_msgs/Pose2D.h"
#include "visualization_msgs/Marker.h"
#include "visualization_msgs/MarkerArray.h"
#include "tf2_geometry_msgs/tf2_geometry_msgs.h"
#include "nav_msgs/Odometry.h"
#include "sensor_msgs/Imu.h"

#define YAW_CONTROL           0
#define LANE_CONTROL          1
#define CONE_TRAFFIC_CONTROL  2
#define OVER_TAKE  			  3
#define MAZE_CONTROL          4
#define MAZE_TURN_90          5


// maximum angular velocity 
#define MAX_L_STEER -28.0
#define MAX_R_STEER  30.0

#define RAD2DEG(x) ((x)*180./M_PI)
#define DEG2RAD(x) ((x)/180.*M_PI)

#define WayPoints_NO 6
#define WayPoint_X_Tor 0.4
#define WayPoint_Y_Tor 0.4

#define SpeedRegion_NO 100

#define rotary_location  0

#define LEFT            -1
#define CENTER           0
#define RIGHT            1

double pos_x = 0.0;
double pos_y = 0.0;
double roll,pitch,yaw;

double r,p,y;


double imu1_roll,imu1_pitch,imu1_yaw;
double imu1_heading_angle_radian;

int    car_speed_base         = 180; //[pwm]
int    steer_car_speed_max    = 255;
int    car_steer_angle        = 0;
int    max_steer_angle        = 30;

double car_yaw_angle          = 0.0;
double car_yaw_angle_d        = 0.0;
float  odom_distance          = 0.0;

int    sonar;
int    traffic_data           = 0;
int    mission_flag           = 0;
int    wall_count 			  = 0;
bool   stop_sign_flag         = false;
double car_linear_odom        = 0.0;   // unit[m]
double car_linear_maze        = 3.0;   // unit[m]
int    detect_traffic_sign    = CENTER;
double target_yaw             = 0.0;

double front_obstacle_distanc = 0.0;

#define RAD2DEG(x) ((x)*180./M_PI)
#define DEG2RAD(x) ((x)/180.*M_PI)

std_msgs::Float32      target_yaw_msg;
std_msgs::Float32      target_overtake_lane_x_msg;

std::string imu1_topic                             = "/handsfree/imu/data";
std::string imu1_yaw_degree_topic                  = "/handsfree/imu/yaw_degree";
std::string imu1_yaw_radian_topic                  = "/handsfree/imu/yaw_radian";
std_msgs::Float32 imu_heading_angle_msg;

 std::string imu_heading_angle_radian_topic         = "/imu/heading_angle_radian";
std::string imu_heading_angle_degree_topic         = "/imu/heading_angle_degree";
std::string imu_heading_angle_offset_degree_topic  = "/imu/heading_angle_offset_degree";


 std::string imu_correction_enable__topic           = "/flag/imu_auto_correction";


struct Point 
{ 
	float x; 
	float y; 
	float z;
};


struct WayPoints
{
	float x;
	float y;
	
} ;

struct Current_Pos
{
	float x = 0.0;
	float y = 0.0;
	float theta = 0.0 ;
} my_pose;

struct region
{
	float left;
	float right;
	float top;
	float bottom;
} speed_region[SpeedRegion_NO];


void imu1Callback(const sensor_msgs::Imu::ConstPtr& msg)
{
    tf2::Quaternion q(
        msg->orientation.x,
        msg->orientation.y,
        msg->orientation.z,
        msg->orientation.w);
    tf2::Matrix3x3 m(q);      
 
    m.getRPY(imu1_roll, imu1_pitch, imu1_yaw);
}

void imu1yawradianCallback(const std_msgs::Float32& msg)
{
	imu1_heading_angle_radian = msg.data;
	if(imu1_heading_angle_radian >= M_PI)  imu1_heading_angle_radian = 2*M_PI - imu1_heading_angle_radian;
    ROS_INFO("Received imu1_heading_angle_radian: %f", imu1_heading_angle_radian);

}


void sonar_Callback(const std_msgs::Int8 & msg)
{
	sonar = msg.data;
	printf("sonar flag : %d\n", sonar);
}

void odom_distance_Callback(const std_msgs::Float32 & msg)
{
	car_linear_odom = msg.data;
}

void front_obstacle_distance_Callback(const std_msgs::Float32 & msg)
{
	front_obstacle_distanc = msg.data;
}

void maze_distance_Callback(const std_msgs::Float32 & msg)
{
	car_linear_maze = msg.data;
}

void trafficCallback(const std_msgs::Int8& msg)
{
	traffic_data = msg.data;
}

void car_control_steer_Callback(const std_msgs::Int16& msg)
{
	car_steer_angle = msg.data;
}

void stop_line_detect_Callback(const std_msgs::Bool& msg)
{
	stop_sign_flag      = msg.data;	
	
}

void traffic_sign_detect_Callback(const std_msgs::Int8& msg)
{
	detect_traffic_sign = msg.data;	
}

int corner_speed_control(int steer_angle, int base_speed, int max_corner_speed)
{
	int speed;
	
	double a, b;
	
	a =(max_corner_speed - base_speed)/(double)max_steer_angle;
	
	b = (double)base_speed;
	
	speed = (int)(a * fabs(steer_angle)) + base_speed;
	
	speed  = (speed >= max_corner_speed) ? max_corner_speed : speed;
	speed  = (speed <=                0) ?                0 : speed;
	
	return speed;
}


int main(int argc, char **argv)
{
	int count = 0;

	ros::init(argc, argv, "aa10_navigation_control");

	ros::NodeHandle n;

	std::string imu1_topic                             = "/handsfree/imu/data";
	std::string imu_yaw_angle_topic                = "/handsfree/imu/yaw_radian";
	std::string yaw_control_mode_topic             = "/Car_Control_Cmd/steering_control_mode";
	std::string imu_heading_angle_radian_topic         = "/imu/heading_angle_radian";
	std::string imu_heading_angle_degree_topic         = "/imu/heading_angle_degree";
	std::string imu_heading_angle_offset_degree_topic  = "/imu/heading_angle_offset_degree";
	std::string traffic_light_topic                    ="/vision/traffic_light";

	
	std::string odom_sub_topic 				       = "/odom";                                    // receive odom or pose
	std::string yaw_control_steering_output_topic  = "/Car_Control_Cmd/steerAngle_Int16";
	std::string car_control_speed_topic            = "/Car_Control_cmd/Speed_Int16";
	std::string lane_control_topic                 = "/flag/lane_control_set";
	std::string maze_control_topic                 = "/flag/maze_control_set";
	std::string traffic_sign_detect_flag_topic     = "/flag/traffic_sign_detect_set";
	std::string odom_distance_topic                = "/odom/distance";
	std::string maze_distance_topic                = "/lidar/front_obstacle_distance";
	
	std::string stop_line_detect_topic             = "/vision/stop_line_detect_flag";
	
	ros::param::get("~imu_yaw_angle_topic",                   imu_yaw_angle_topic);     	
	ros::param::get("~yaw_control_mode_topic",                yaw_control_mode_topic);
	
	ros::param::get("~odom_sub_topic",                        odom_sub_topic);
	ros::param::get("~yaw_control_steering_output_topic",     yaw_control_steering_output_topic);
	ros::param::get("~stop_line_detect_topic"           ,     stop_line_detect_topic);
	
	ros::param::get("~yaw_control_steering_output_topic",     yaw_control_steering_output_topic);
	
	
	ros::Subscriber sub_obstacle_detect_distance        = n.subscribe("/lidar/front_obstacel_distance", 1, front_obstacle_distance_Callback);
	ros::Subscriber sub_car_control_steer               = n.subscribe(yaw_control_steering_output_topic, 1, car_control_steer_Callback);
	ros::Subscriber sub_stop_line_detect                = n.subscribe(stop_line_detect_topic , 1, stop_line_detect_Callback);
	ros::Subscriber sub_odom_distance                   = n.subscribe(odom_distance_topic , 1, odom_distance_Callback);
	ros::Subscriber sub_maze_distance                   = n.subscribe(maze_distance_topic , 1, maze_distance_Callback);
	ros::Subscriber sub_imu1                     		 = n.subscribe("/handsfree/imu/yaw_degree",1,&imu1Callback);
	ros::Subscriber sub_imu1_yaw_radian        		   = n.subscribe("/handsfree/imu/yaw_radian",1,&imu1yawradianCallback);
	ros::Subscriber sub_traffic_light                   = n.subscribe(traffic_light_topic, 1, &trafficCallback);
			
	ros::Publisher  traffic_sign_detect_flag_pub        = n.advertise<std_msgs::Bool>(traffic_sign_detect_flag_topic, 1);
	ros::Publisher  lane_control_topic_pub              = n.advertise<std_msgs::Bool>(lane_control_topic, 1);
	ros::Publisher  maze_control_topic_pub              = n.advertise<std_msgs::Bool>(maze_control_topic, 1);
	ros::Publisher  yaw_control_mode_pub                = n.advertise<std_msgs::Int8>(yaw_control_mode_topic, 1);
	ros::Publisher  car_control_speed_topic_pub         = n.advertise<std_msgs::Int16>(car_control_speed_topic, 1);
	ros::Publisher target_yaw_pub                       = n.advertise<std_msgs::Float32>("/Car_Control_Cmd/Target_Angle", 1);
	ros::Publisher target_overtake_lane_x_pub           = n.advertise<std_msgs::Float32>("/target/overtake_lane_x", 1);
    ros::Publisher imu_heading_angle_radian_pub   = n.advertise<std_msgs::Float32>(imu_heading_angle_radian_topic, 1);

    std_msgs::Float32 headangle_msg;
    std_msgs::Bool  lane_control_flag_msg;
    std_msgs::Int16 car_control_speed_msg;
    std_msgs::Int8  yaw_control_mode_msg;
    std_msgs::Bool	traffic_sign_detect_msg;
    std_msgs::Bool  maze_control_flag_msg;
	ros::Rate loop_rate(30);  // 10
	int mission_flag=10;
	double obs_distance=0;
	ros::param::get("~mission_flag",                   mission_flag);  
	ros::param::get("~obs_distance",                   obs_distance);  
	
	double car_linear_odom_temp   = 0.0;   // unit[m]
	double car_yaw_angle_d_temp   = 0.0;
	double car_move_distance      = 0.0;   // unit[m] 
	while (ros::ok())
	{
				boost::shared_ptr<sensor_msgs::Imu const> shared_imu1_topic, shared_imu2_topic;

		ROS_INFO("Mission flag : %2d | Speed :%3d   | Steer :%3d", mission_flag,car_control_speed_msg.data,car_steer_angle );
		switch(mission_flag)
		{
			case 0 :  // vision control //
					lane_control_flag_msg.data = true;
					lane_control_topic_pub.publish(lane_control_flag_msg);
					
					traffic_sign_detect_msg.data = false;
					traffic_sign_detect_flag_pub.publish(traffic_sign_detect_msg);
					
					yaw_control_mode_msg.data = LANE_CONTROL;
					yaw_control_mode_pub.publish(yaw_control_mode_msg);
					
					//traffic_data
				    ROS_INFO("Mission Lane Detection");
				    ROS_INFO("Traffic_data : %d",traffic_data);
				    //car_control_speed_msg.data = corner_speed_control(car_steer_angle, car_speed_base, steer_car_speed_max);
				    car_control_speed_msg.data = -250;
				    if(stop_sign_flag == true)
					{
						ROS_INFO("Mission First Stop Detection");
						car_yaw_angle_d_temp = (imu1_heading_angle_radian*180)/M_PI;
						car_control_speed_msg.data = 0;
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						ros::Duration(2.0).sleep();
						traffic_sign_detect_msg.data = true;
						traffic_sign_detect_flag_pub.publish(traffic_sign_detect_msg);
						ros::Duration(1.0).sleep();
						mission_flag++;
					}
					car_control_speed_topic_pub.publish(car_control_speed_msg);
					break;
												
			case 1 : // wait for traffic sign detection result
					ROS_INFO("Traffic Sign Detection");
					
					lane_control_flag_msg.data = false;
					lane_control_topic_pub.publish(lane_control_flag_msg);					
					
					ros::Duration(3.0).sleep();
					detect_traffic_sign = RIGHT;   //not working
					if(detect_traffic_sign == CENTER)//(traffic_data == 2)
					{
						mission_flag = 2;
					
					}
					else if(detect_traffic_sign == RIGHT)//(traffic_data == 3)
					{
						mission_flag = 3;
					}
					
					else
					{
						
					}
					car_linear_odom_temp = car_linear_odom;
					car_yaw_angle_d_temp ;
					// car start
					
					car_control_speed_msg.data = 0;                                       // stop
					car_control_speed_topic_pub.publish(car_control_speed_msg);
					
					
					break;
					

			case 2 : // straight yaw control
					lane_control_flag_msg.data = false;
					lane_control_topic_pub.publish(lane_control_flag_msg);
					traffic_sign_detect_msg.data = false;
					traffic_sign_detect_flag_pub.publish(traffic_sign_detect_msg);
					car_control_speed_msg.data = -250;                                       // stop
					car_control_speed_topic_pub.publish(car_control_speed_msg);
					
					car_move_distance =  car_linear_odom - car_linear_odom_temp;
					 
					if(car_move_distance >= 1.8)
					{
						mission_flag = 4;													//직진 다음미션 플레그로 가기
					}
					break;		
					
			case 3 : // right turn
					lane_control_flag_msg.data = false;
					lane_control_topic_pub.publish(lane_control_flag_msg);
					traffic_sign_detect_msg.data = false;
					traffic_sign_detect_flag_pub.publish(traffic_sign_detect_msg);
					car_control_speed_msg.data = -250;                                       // stop
					car_control_speed_topic_pub.publish(car_control_speed_msg);
					
					car_move_distance =  car_linear_odom - car_linear_odom_temp;
					
					// trage yaw control = right turn
					if(car_move_distance <= 1.27){
						//target_yaw = car_yaw_angle_d_temp  - 41;
					}
					else{
						car_control_speed_msg.data = -250;                                       // stop
					    car_control_speed_topic_pub.publish(car_control_speed_msg);
						target_yaw = car_yaw_angle_d_temp -30;
						yaw_control_mode_msg.data = YAW_CONTROL;
						yaw_control_mode_pub.publish(yaw_control_mode_msg);					
						target_yaw_msg.data = target_yaw;
						target_yaw_pub.publish(target_yaw_msg);
					}
					
					if(car_move_distance >= 4.1)
					{
						mission_flag = 5;
					}					
					
					break;				
					
			case 4 : // vision control 직진
					lane_control_flag_msg.data = true;
					lane_control_topic_pub.publish(lane_control_flag_msg);
					car_move_distance =  car_linear_odom - car_linear_odom_temp;
					if(car_move_distance >= 15.0)//stop_sign_flag == true
					if(car_move_distance >= 15.0)//stop_sign_flag == true
					{
						car_control_speed_msg.data = 0;                                       // stop
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						//ROS_INFO("Mission Second Stop Detection");
						yaw_control_mode_msg.data = YAW_CONTROL;
						yaw_control_mode_pub.publish(yaw_control_mode_msg);
						lane_control_flag_msg.data = false;
						lane_control_topic_pub.publish(lane_control_flag_msg);
						target_yaw = car_yaw_angle_d_temp  + 44;
						target_yaw_msg.data = target_yaw;
						target_yaw_pub.publish(target_yaw_msg);
						
						//car_control_speed_msg.data = 0;
						//car_control_speed_topic_pub.publish(car_control_speed_msg);
						//ros::Duration(2.0).sleep();
						if(car_move_distance >= 5.2)  mission_flag = 7;
					}		
					break;			
					
					
			case 5 : // right turn_2
			
					car_move_distance =  car_linear_odom - car_linear_odom_temp;
					//car_control_speed_msg.data = 0;
					//car_control_speed_topic_pub.publish(car_control_speed_msg);
					if(car_move_distance >= 10.6)//stop_sign_flag == true
					{
						car_control_speed_msg.data = -250;
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						//ROS_INFO("Mission Second Stop Detection");
						yaw_control_mode_msg.data = YAW_CONTROL;
						yaw_control_mode_pub.publish(yaw_control_mode_msg);
						lane_control_flag_msg.data = false;
						lane_control_topic_pub.publish(lane_control_flag_msg);
						target_yaw = car_yaw_angle_d_temp  - 58;
						target_yaw_msg.data = target_yaw;
						target_yaw_pub.publish(target_yaw_msg);
						//car_control_speed_msg.data = 0;
						//car_control_speed_topic_pub.publish(car_control_speed_msg);
						//ros::Duration(2.0).sleep();
						if(car_move_distance >= 11.3)  mission_flag = 7;
					}
					else{
						lane_control_flag_msg.data = true;
						lane_control_topic_pub.publish(lane_control_flag_msg);
						yaw_control_mode_msg.data = LANE_CONTROL;
						yaw_control_mode_pub.publish(yaw_control_mode_msg);
						}
					break;		
					
			case 7:
			
				    lane_control_flag_msg.data = true;
					lane_control_topic_pub.publish(lane_control_flag_msg);
					yaw_control_mode_msg.data = LANE_CONTROL;
					yaw_control_mode_pub.publish(yaw_control_mode_msg);
					car_control_speed_msg.data = -250;
					 if(stop_sign_flag == true)
					{
						ROS_INFO("Mission First Stop Detection");
						
						car_control_speed_msg.data = 0;
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						ros::Duration(3.0).sleep();
						car_linear_odom_temp = car_linear_odom;
						car_yaw_angle_d_temp = (imu1_heading_angle_radian*180)/M_PI;
						mission_flag++;

					}
					car_control_speed_topic_pub.publish(car_control_speed_msg);
					break;	

					
			case 8:											// second track Right 회피
					lane_control_flag_msg.data = false;
					lane_control_topic_pub.publish(lane_control_flag_msg);
					yaw_control_mode_msg.data = YAW_CONTROL;
					yaw_control_mode_pub.publish(yaw_control_mode_msg);
					//car_control_speed_msg.data = -200;
					//car_control_speed_topic_pub.publish(car_control_speed_msg);
					car_move_distance =  car_linear_odom - car_linear_odom_temp;
					if(car_move_distance <= 0.7)
					{
						car_control_speed_topic_pub.publish(car_control_speed_msg);				
						target_yaw_msg.data = car_yaw_angle_d_temp;
						target_yaw_pub.publish(target_yaw_msg);
						car_control_speed_msg.data = -250;
						car_control_speed_topic_pub.publish(car_control_speed_msg);
					
					}
					else if((car_move_distance > 0.7) && (car_move_distance < 2.8))
					{
						car_control_speed_msg.data = -250;
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						target_yaw = car_yaw_angle_d_temp - 18;
						target_yaw_msg.data = target_yaw;
						target_yaw_pub.publish(target_yaw_msg);
					}
					else if((car_move_distance > 2.8) && (car_move_distance <= 4.8))
					{	
						car_control_speed_msg.data = -180;
					    car_control_speed_topic_pub.publish(car_control_speed_msg);				
						car_yaw_angle_d_temp = imu1_heading_angle_radian;
						target_yaw = car_yaw_angle_d_temp + 36;
						target_yaw_msg.data = target_yaw;
						target_yaw_pub.publish(target_yaw_msg);
					}
					else if(car_move_distance > 5.0)
					{	
						car_control_speed_msg.data = -180;
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						mission_flag++;
					}
					break;
					
				case 9:	
					car_control_speed_msg.data = -180;
					car_control_speed_topic_pub.publish(car_control_speed_msg);
					yaw_control_mode_msg.data = OVER_TAKE;
					yaw_control_mode_pub.publish(yaw_control_mode_msg);
					target_overtake_lane_x_msg.data = 1.35;
					target_overtake_lane_x_pub.publish(target_overtake_lane_x_msg);
					if (wall_count == 1)
					{
					car_move_distance =  car_linear_odom - car_linear_odom_temp;
						if(car_move_distance > 1.2)
						{
							yaw_control_mode_msg.data = YAW_CONTROL;
							yaw_control_mode_pub.publish(yaw_control_mode_msg);
							target_yaw = car_yaw_angle_d_temp + 30;
							target_yaw_msg.data = target_yaw;
							target_yaw_pub.publish(target_yaw_msg);
						}
					yaw_control_mode_msg.data = OVER_TAKE;
					yaw_control_mode_pub.publish(yaw_control_mode_msg);
					target_overtake_lane_x_msg.data = 0.85;
					target_overtake_lane_x_pub.publish(target_overtake_lane_x_msg);
					}
					if (front_obstacle_distanc <= 1.0)
					{
					wall_count++;
					}
					break;

					
					
				case 10:
					lane_control_flag_msg.data = true;
					lane_control_topic_pub.publish(lane_control_flag_msg);
					yaw_control_mode_msg.data = LANE_CONTROL;
					yaw_control_mode_pub.publish(yaw_control_mode_msg);
				    car_control_speed_msg.data = 200;
					car_control_speed_topic_pub.publish(car_control_speed_msg);
					
						if(stop_sign_flag == true)
					{
						ROS_INFO("Mission parking Stop Detection");
						car_control_speed_msg.data = 0;
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						ros::Duration(2.0).sleep();
						car_yaw_angle_d_temp = (imu1_heading_angle_radian*180)/M_PI;			// heading 초기화
						car_linear_odom_temp = car_linear_odom;								    // odom 초기화
						mission_flag = 11;
					}
					break;
					
				case 11:
						lane_control_flag_msg.data = false;
						lane_control_topic_pub.publish(lane_control_flag_msg);
						car_move_distance =  car_linear_odom - car_linear_odom_temp;
						target_yaw = car_yaw_angle_d_temp;
						target_yaw_msg.data = target_yaw;
						target_yaw_pub.publish(target_yaw_msg);
						
						yaw_control_mode_msg.data = YAW_CONTROL;
						yaw_control_mode_pub.publish(yaw_control_mode_msg);
						
						car_control_speed_msg.data = 200;
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						
									
						if((car_move_distance >= 2.6))										// 처음 회전각을 위해 전진 하는거 수치 수정 요망
						{
							car_control_speed_msg.data = 180;
							car_control_speed_topic_pub.publish(car_control_speed_msg);
							car_yaw_angle_d_temp = (imu1_heading_angle_radian*180)/M_PI;			// heading 초기화
							car_linear_odom_temp = car_linear_odom;	
							mission_flag = 12;
						}
				        break;
				        
				 case 12:
						lane_control_flag_msg.data = false;
						lane_control_topic_pub.publish(lane_control_flag_msg);
						
				
						target_yaw = car_yaw_angle_d_temp - 120;
						target_yaw_msg.data = target_yaw;
						target_yaw_pub.publish(target_yaw_msg);
						yaw_control_mode_msg.data = YAW_CONTROL;
						yaw_control_mode_pub.publish(yaw_control_mode_msg);							

						
						car_control_speed_msg.data = 180;
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						
						car_move_distance =  car_linear_odom - car_linear_odom_temp;
									
						if((car_move_distance > 3.2))										// 처음 회전각을 위해 전진 하는거 수치 수정 요망
						{
							car_yaw_angle_d_temp = (imu1_heading_angle_radian*180)/M_PI;			// heading 초기화
							car_linear_odom_temp = car_linear_odom;
							mission_flag = 13;
						}
				        break;
				case 13:
						lane_control_flag_msg.data = true;
						lane_control_topic_pub.publish(lane_control_flag_msg);
						yaw_control_mode_msg.data = LANE_CONTROL;
						yaw_control_mode_pub.publish(yaw_control_mode_msg);
						car_control_speed_msg.data = 180;
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						car_move_distance =  car_linear_odom - car_linear_odom_temp;
						if((car_move_distance > 6.5))												// 처음 회전각을 위해 전진 하는거 수치 수정 요망
						{
							car_yaw_angle_d_temp = (imu1_heading_angle_radian*180)/M_PI;			// heading 초기화
							car_linear_odom_temp = car_linear_odom;
							mission_flag = 14;
						}
				        break;
				
				case 14:	
							lane_control_flag_msg.data = false;
							lane_control_topic_pub.publish(lane_control_flag_msg);			
							target_yaw = car_yaw_angle_d_temp;
							target_yaw_msg.data = target_yaw+3;
							target_yaw_pub.publish(target_yaw_msg);
							yaw_control_mode_msg.data = YAW_CONTROL;
							yaw_control_mode_pub.publish(yaw_control_mode_msg);
							car_move_distance =  car_linear_odom - car_linear_odom_temp;
						if((car_move_distance > 1.9))										
						{
							car_control_speed_msg.data = 0;
							car_control_speed_topic_pub.publish(car_control_speed_msg);
							ros::Duration(2.0).sleep();
							car_yaw_angle_d_temp = (imu1_heading_angle_radian*180)/M_PI;			// heading 초기화
							car_linear_odom_temp = car_linear_odom;
							mission_flag = 15;
						}

				

						
						break;
				
				case 15:
						if((car_move_distance < 0.45))										
						{
						target_yaw = car_yaw_angle_d_temp+10;
						target_yaw_msg.data = target_yaw;
						target_yaw_pub.publish(target_yaw_msg);
						}
						
						else if (car_move_distance >= 0.45 && car_move_distance <= 4.0)
						{
							car_move_distance =  car_linear_odom - car_linear_odom_temp;
							target_yaw = car_yaw_angle_d_temp + 100;
							target_yaw_msg.data = target_yaw;
							target_yaw_pub.publish(target_yaw_msg);
						}
						
						yaw_control_mode_msg.data = 6;
						yaw_control_mode_pub.publish(yaw_control_mode_msg);
						car_control_speed_msg.data = -180;
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						
						car_move_distance =  car_linear_odom_temp - car_linear_odom;
									
						if((car_move_distance > 4.0))										// 처음 회전각을 위해 전진 하는거 수치 수정 요망
						{
							car_yaw_angle_d_temp = (imu1_heading_angle_radian*180)/M_PI;			// heading 초기화
							mission_flag = 16;
						}
				        break;
				 case 16:
						{
						car_control_speed_msg.data = 0;
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						ros::Duration(2.0).sleep();
						car_linear_odom_temp = car_linear_odom;
						mission_flag = 17;
						car_linear_odom_temp = car_linear_odom;
						car_yaw_angle_d_temp = (imu1_heading_angle_radian*180)/M_PI;						
						}
						break;
						
				case 17:
						{
						yaw_control_mode_msg.data = YAW_CONTROL;
						yaw_control_mode_pub.publish(yaw_control_mode_msg);
						car_move_distance =  car_linear_odom - car_linear_odom_temp;
						car_control_speed_msg.data = 180;
							car_control_speed_topic_pub.publish(car_control_speed_msg);
				/*		if (car_move_distance < 0.3)
						{
							target_yaw = car_yaw_angle_d_temp;
							target_yaw_msg.data = target_yaw+60;
							target_yaw_pub.publish(target_yaw_msg);
						}*/
						
				 		if (car_move_distance <= 2.0)
						{
							target_yaw = car_yaw_angle_d_temp;
							target_yaw_msg.data = target_yaw+130;
							target_yaw_pub.publish(target_yaw_msg);
						}
						else if (car_move_distance >2.0 && car_move_distance <= 7.0)
						{
							lane_control_flag_msg.data = true;
							lane_control_topic_pub.publish(lane_control_flag_msg);
							yaw_control_mode_msg.data = LANE_CONTROL;
							yaw_control_mode_pub.publish(yaw_control_mode_msg);
						}
						else if (car_move_distance >7.0 && car_move_distance <= 8.5)
						{
							yaw_control_mode_msg.data = YAW_CONTROL;
							yaw_control_mode_pub.publish(yaw_control_mode_msg);
							target_yaw_msg.data = target_yaw+60;
							target_yaw_pub.publish(target_yaw_msg);
						}
						else
						{
							lane_control_flag_msg.data = true;
							lane_control_topic_pub.publish(lane_control_flag_msg);
							yaw_control_mode_msg.data = LANE_CONTROL;
							yaw_control_mode_pub.publish(yaw_control_mode_msg);
						}

						}
				
					break;
				///////////////////////////maze stage//////////////////////////
					case 18:
					{
						car_linear_odom_temp = car_linear_odom;								    // odom 초기화
						mission_flag ++;
					}
					break;
					case 19:
					{
						car_control_speed_msg.data = 120;
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						car_move_distance =  car_linear_odom - car_linear_odom_temp;
						if(car_move_distance > 1.1)
						{
							mission_flag ++;
						}
					}
					break;
							
					
					case 20:
						lane_control_flag_msg.data = false;
						lane_control_topic_pub.publish(lane_control_flag_msg);
						maze_control_flag_msg.data = true;
						maze_control_topic_pub.publish(maze_control_flag_msg);
						yaw_control_mode_msg.data = 4;
						yaw_control_mode_pub.publish(yaw_control_mode_msg);
						car_control_speed_msg.data = 160;                                       // stop
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						printf("distance : %6.3lf\n",car_linear_maze);
						if(car_linear_maze<=(float)obs_distance)
						{
							car_control_speed_msg.data = 0;                                       // stop
							car_control_speed_topic_pub.publish(car_control_speed_msg);
							//ros::Duration(0.5).sleep();
							car_linear_odom_temp = car_linear_odom;
							mission_flag += 2;
						}
						break;
					case 21:
						car_control_speed_msg.data = 0;                                       // stop
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						yaw_control_mode_msg.data = 4;
					
						printf("distance : %6.3lf\n",car_linear_maze);
						//ros::Duration(3.0).sleep();
						break;
				
					case 22:
						yaw_control_mode_msg.data = 5;
						yaw_control_mode_pub.publish(yaw_control_mode_msg);
						car_move_distance =  car_linear_odom - car_linear_odom_temp;
						car_control_speed_msg.data = 140;                                       // stop
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						//car_yaw_angle_d_temp = imu1_heading_angle_radian;
						//target_yaw = car_yaw_angle_d_temp  - 44;
						//target_yaw_msg.data = target_yaw;
						//target_yaw_pub.publish(target_yaw_msg);
						if(car_move_distance >= 7.9)
						{
							//car_control_speed_msg.data = -180;                                       // stop
							//car_control_speed_topic_pub.publish(car_control_speed_msg);
							mission_flag ++;
						}
					
						break;
					case 23:
						lane_control_flag_msg.data = false;
						lane_control_topic_pub.publish(lane_control_flag_msg);
						
						yaw_control_mode_msg.data = 4;
						yaw_control_mode_pub.publish(yaw_control_mode_msg);
						car_control_speed_msg.data = 160;                                       // stop
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						printf("distance : %6.3lf\n",car_linear_maze);
						if(car_move_distance >= 4.0)
						{
							mission_flag ++;
						}
						break;
							
					case 24:
						lane_control_flag_msg.data = true;
						lane_control_topic_pub.publish(lane_control_flag_msg);
						maze_control_flag_msg.data = false;
						maze_control_topic_pub.publish(maze_control_flag_msg);
						yaw_control_mode_msg.data = LANE_CONTROL;
						yaw_control_mode_pub.publish(yaw_control_mode_msg);
						break;
					
					
					
					
					
				/*	
				case 9:
					lane_control_flag_msg.data = false;
					lane_control_topic_pub.publish(lane_control_flag_msg);
					yaw_control_mode_msg.data = 4;
					yaw_control_mode_pub.publish(yaw_control_mode_msg);
					car_control_speed_msg.data = -120;                                       // stop
					car_control_speed_topic_pub.publish(car_control_speed_msg);
					printf("distance : %6.3lf\n",car_linear_maze);
					if(car_linear_maze<=(float)obs_distance)
					{
						car_control_speed_msg.data = 0;                                       // stop
						car_control_speed_topic_pub.publish(car_control_speed_msg);
						//ros::Duration(0.5).sleep();
						car_linear_odom_temp = car_linear_odom;
						mission_flag = 11;
					}
					break;
				case 10:
					car_control_speed_msg.data = 0;                                       // stop
					car_control_speed_topic_pub.publish(car_control_speed_msg);
					yaw_control_mode_msg.data = 4;
					
					printf("distance : %6.3lf\n",car_linear_maze);
					//ros::Duration(3.0).sleep();
					break;
				
				case 11:
					yaw_control_mode_msg.data = 5;
					yaw_control_mode_pub.publish(yaw_control_mode_msg);
					car_move_distance =  car_linear_odom - car_linear_odom_temp;
					car_control_speed_msg.data = -180;                                       // stop
					car_control_speed_topic_pub.publish(car_control_speed_msg);
					//car_yaw_angle_d_temp = imu1_heading_angle_radian;
					//target_yaw = car_yaw_angle_d_temp  - 44;
					//target_yaw_msg.data = target_yaw;
					//target_yaw_pub.publish(target_yaw_msg);
					if(car_move_distance >= 1.6)
					{
						//car_control_speed_msg.data = -180;                                       // stop
						//car_control_speed_topic_pub.publish(car_control_speed_msg);
						mission_flag ++;
					}
					
					break;
				case 12:
					lane_control_flag_msg.data = false;
					lane_control_topic_pub.publish(lane_control_flag_msg);
					yaw_control_mode_msg.data = 4;
					yaw_control_mode_pub.publish(yaw_control_mode_msg);
					car_control_speed_msg.data = -120;                                       // stop
					car_control_speed_topic_pub.publish(car_control_speed_msg);
					printf("distance : %6.3lf\n",car_linear_maze);

					/*case 13:
					car_control_speed_msg.data = -100;                                       // stop
					car_control_speed_topic_pub.publish(car_control_speed_msg);
					car_move_distance =  car_linear_odom - car_linear_odom_temp;
					yaw_control_mode_msg.data = 5;
					car_yaw_angle_d_temp = imu1_heading_angle_radian;
					target_yaw = car_yaw_angle_d_temp  - 44;
					target_yaw_msg.data = target_yaw;
					target_yaw_pub.publish(target_yaw_msg);
					
					if(car_move_distance >= 0.784)
					{
						mission_flag ++;
					}
					break;
					case 14:
					lane_control_flag_msg.data = false;
					lane_control_topic_pub.publish(lane_control_flag_msg);
					yaw_control_mode_msg.data = 4;
					yaw_control_mode_pub.publish(yaw_control_mode_msg);
					car_control_speed_msg.data = -150;                                       // stop
					car_control_speed_topic_pub.publish(car_control_speed_msg);
					break;*/
			
		}
		headangle_msg.data = imu1_heading_angle_radian;
		imu_heading_angle_radian_pub.publish(headangle_msg);
		loop_rate.sleep();
		ros::spinOnce();

		++count;
	}
	return 0;
}







